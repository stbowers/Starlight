﻿using System;
namespace FinalProject.Graphics
{
	public class BatchRenderer
	{
		public BatchRenderer(Driver driver)
		{
		}
	}
}
