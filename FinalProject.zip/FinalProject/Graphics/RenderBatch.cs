﻿using System;
namespace FinalProject
{
	public interface RenderBatch
	{
	}
}
