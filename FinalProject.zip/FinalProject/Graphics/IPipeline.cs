﻿using System;
namespace FinalProject.Graphics
{
	public interface IPipeline
	{
	}
}
