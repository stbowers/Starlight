﻿using System;
namespace FinalProject
{
	public class GameClient
	{
	}
}
