﻿using System;
namespace FinalProject
{
	public interface Socket
	{
	}
}
